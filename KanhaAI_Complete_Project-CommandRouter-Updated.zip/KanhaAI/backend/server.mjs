import "dotenv/config";
import express from "express";
import cors from "cors";
import OpenAI from "openai";

const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));

const port = Number(process.env.PORT || 8787);
const model = process.env.OPENAI_MODEL || "gpt-5.6-luna";

if (!process.env.OPENAI_API_KEY) {
  console.warn("OPENAI_API_KEY is not set. The server will start, but AI calls will fail.");
}

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const instructions = `
You are Kanha AI, a friendly Indian personal Android assistant.
Understand Hindi, Hinglish, English and common Odia phrases.
Return ONLY valid JSON with this exact schema:
{
  "reply": "short natural response",
  "action": "none|open_youtube|open_chrome|open_whatsapp|open_camera|open_maps|open_settings|open_url|dial|whatsapp_message|accessibility_click",
  "value": "optional action value",
  "needsConfirmation": false
}

Rules:
- If the user is asking a normal question, action=none.
- "YouTube kholo" => open_youtube.
- "Chrome kholo" => open_chrome.
- "WhatsApp kholo" => open_whatsapp.
- "Camera kholo" => open_camera.
- "Settings kholo" => open_settings.
- "Maps kholo [place]" => open_maps with value=place.
- "website open karo example.com" => open_url with value=example.com.
- "call/dial 987..." => dial with value=the number. Use the Android dialer; do not auto-place the call.
- "WhatsApp par message ..." => whatsapp_message with value=message text. The Android app will open the compose screen and the user must press Send.
- If the user explicitly asks to click visible UI text in another app, use accessibility_click with value equal to the visible text.
- Never request or handle passwords, OTPs, PINs, banking credentials or payment confirmation. Keep those manual.
- Never invent an action outside the allowed list.
- Keep replies concise and natural.
`;

function extractText(response) {
  if (typeof response.output_text === "string" && response.output_text.trim()) {
    return response.output_text.trim();
  }
  let out = "";
  for (const item of response.output || []) {
    for (const part of item.content || []) {
      if (part.type === "output_text" && part.text) out += part.text;
    }
  }
  return out.trim();
}

function safeJson(text) {
  const cleaned = text
    .replace(/^```json\s*/i, "")
    .replace(/^```\s*/i, "")
    .replace(/\s*```$/i, "")
    .trim();
  try {
    return JSON.parse(cleaned);
  } catch {
    const start = cleaned.indexOf("{");
    const end = cleaned.lastIndexOf("}");
    if (start >= 0 && end > start) return JSON.parse(cleaned.slice(start, end + 1));
    throw new Error("Model did not return JSON.");
  }
}

app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "Kanha AI backend", model });
});

app.post("/api/command", async (req, res) => {
  try {
    const message = String(req.body?.message || "").trim();
    if (!message) return res.status(400).json({ error: "message is required" });

    const response = await client.responses.create({
      model,
      instructions,
      input: message,
      max_output_tokens: 300
    });

    const raw = extractText(response);
    const data = safeJson(raw);

    const allowed = new Set([
      "none",
      "open_youtube",
      "open_chrome",
      "open_whatsapp",
      "open_camera",
      "open_maps",
      "open_settings",
      "open_url",
      "dial",
      "whatsapp_message",
      "accessibility_click"
    ]);

    const action = allowed.has(data.action) ? data.action : "none";

    res.json({
      reply: String(data.reply || "Okay."),
      action,
      value: String(data.value || ""),
      needsConfirmation: Boolean(data.needsConfirmation)
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      error: "AI request failed",
      detail: error?.message || "unknown error"
    });
  }
});

app.listen(port, "0.0.0.0", () => {
  console.log(`Kanha AI backend running on http://0.0.0.0:${port}`);
});
