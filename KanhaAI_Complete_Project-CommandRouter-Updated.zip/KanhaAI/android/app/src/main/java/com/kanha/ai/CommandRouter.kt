package com.kanha.ai

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

object CommandRouter {

    fun execute(context: Context, action: String, value: String): String {
        return try {
            when (action) {
                "open_youtube" -> {
                    context.startActivity(
                        Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))
                    )
                    "YouTube opened."
                }

                "open_chrome" -> {
                    val intent = context.packageManager
                        .getLaunchIntentForPackage("com.android.chrome")

                    if (intent != null) {
                        context.startActivity(intent)
                    } else {
                        context.startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))
                        )
                    }

                    "Chrome opened."
                }

                "open_whatsapp" -> {
                    val intent = context.packageManager
                        .getLaunchIntentForPackage("com.whatsapp")

                    if (intent != null) {
                        context.startActivity(intent)
                    } else {
                        context.startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.whatsapp.com"))
                        )
                    }

                    "WhatsApp opened."
                }

                "open_camera" -> {
                    context.startActivity(
                        Intent("android.media.action.IMAGE_CAPTURE")
                    )
                    "Camera opened."
                }

                "open_maps" -> {
                    val q = value.ifBlank { "Bhubaneswar" }

                    context.startActivity(
                        Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse("geo:0,0?q=" + Uri.encode(q))
                        )
                    )

                    "Maps opened."
                }

                "open_settings" -> {
                    context.startActivity(
                        Intent(Settings.ACTION_SETTINGS)
                    )
                    "Android Settings opened."
                }

                "open_url" -> {
                    val url = if (value.startsWith("http")) {
                        value
                    } else {
                        "https://$value"
                    }

                    context.startActivity(
                        Intent(Intent.ACTION_VIEW, Uri.parse(url))
                    )

                    "Website opened."
                }

                "dial" -> {
                    val number = value.filter {
                        it.isDigit() || it == '+' || it == '*' || it == '#'
                    }

                    context.startActivity(
                        Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number"))
                    )

                    "Dialer opened for $number."
                }

                "whatsapp_message" -> {
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        setPackage("com.whatsapp")
                        putExtra(Intent.EXTRA_TEXT, value)
                    }

                    context.startActivity(intent)

                    "WhatsApp compose screen opened. Please press Send yourself."
                }

                "accessibility_click" -> {
                    KanhaAccessibilityService.clickVisibleText(value)
                    "I tried to click \"$value\" on the visible screen."
                }

                "none" -> ""

                else -> {
                    "I understood the request, but that action is not available yet."
                }
            }
        } catch (e: Exception) {
            "I couldn't perform that action: ${e.message ?: "unknown error"}"
        }
    }
}
