package com.kanha.ai

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityNodeInfo

class KanhaAccessibilityService : AccessibilityService() {

    companion object {
        private var instance: KanhaAccessibilityService? = null

        fun clickVisibleText(text: String) {
            instance?.clickText(text)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    private fun clickText(text: String) {
        val root = rootInActiveWindow ?: return
        val nodes = root.findAccessibilityNodeInfosByText(text)
        val node = nodes.firstOrNull() ?: return
        val target = if (node.isClickable) node else clickableParent(node)
        target?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun clickableParent(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var current: AccessibilityNodeInfo? = node.parent
        while (current != null) {
            if (current.isClickable) return current
            current = current.parent
        }
        return null
    }
}
