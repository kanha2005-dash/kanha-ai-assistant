package com.kanha.ai

import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

data class AiResult(
    val reply: String,
    val action: String = "none",
    val value: String = "",
    val needsConfirmation: Boolean = false
)

object BackendClient {
    fun ask(baseUrl: String, message: String): AiResult {
        val url = URL(baseUrl.trimEnd('/') + "/api/command")
        val connection = url.openConnection() as HttpURLConnection
        connection.requestMethod = "POST"
        connection.connectTimeout = 15000
        connection.readTimeout = 45000
        connection.doOutput = true
        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")

        val body = JSONObject().put("message", message).toString()
        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

        val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
        val response = stream.bufferedReader().use { it.readText() }

        if (connection.responseCode !in 200..299) {
            throw IllegalStateException("Backend ${connection.responseCode}: $response")
        }

        val json = JSONObject(response)
        return AiResult(
            reply = json.optString("reply", "I couldn't understand that."),
            action = json.optString("action", "none"),
            value = json.optString("value", ""),
            needsConfirmation = json.optBoolean("needsConfirmation", false)
        )
    }
}
