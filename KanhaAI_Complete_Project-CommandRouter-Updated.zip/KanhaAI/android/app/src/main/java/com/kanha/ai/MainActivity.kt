package com.kanha.ai

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale
import java.util.concurrent.Executors

private val Black = Color(0xFF080604)
private val Gold = Color(0xFFFFC94A)
private val GoldDark = Color(0xFF8F641B)
private val Card = Color(0xFF18120A)
private val White = Color(0xFFFFF8E8)
private val Muted = Color(0xFFCBBE9B)

data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private var speechRecognizer: SpeechRecognizer? = null
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var prefs: SharedPreferences

    private val requestMic = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        prefs = getSharedPreferences("kanha", Context.MODE_PRIVATE)
        tts = TextToSpeech(this, this)

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestMic.launch(Manifest.permission.RECORD_AUDIO)
        }

        setContent {
            KanhaTheme {
                KanhaApp(
                    initialUrl = prefs.getString("backend_url", "http://127.0.0.1:8787")
                        ?: "http://127.0.0.1:8787",
                    savedVoice = prefs.getString("voice_name", "") ?: "",
                    onSaveUrl = { prefs.edit().putString("backend_url", it).apply() },
                    availableVoices = availableVoices(),
                    onSaveVoice = { prefs.edit().putString("voice_name", it).apply(); setVoice(it) },
                    onOpenAccessibility = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
                    onSpeak = { speak(it) },
                    onVoice = { startVoice(it) },
                    onSend = { sendCommand(it) }
                )
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale("en", "IN")
            setVoice(prefs.getString("voice_name", "") ?: "")
        }
    }

    private fun availableVoices(): List<Voice> {
        return if (::tts.isInitialized) {
            tts.voices.orEmpty()
                .filter { it.locale.language == "en" && it.locale.country == "IN" }
                .sortedBy { it.name }
        } else emptyList()
    }

    private fun setVoice(name: String) {
        if (!::tts.isInitialized) return
        val voice = tts.voices?.firstOrNull { it.name == name }
            ?: availableVoices().firstOrNull()
        if (voice != null) tts.voice = voice
    }

    private fun speak(text: String) {
        if (::tts.isInitialized) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "kanha-${System.currentTimeMillis()}")
        }
    }

    private fun startVoice(onText: (String) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("Speech recognition is not available on this phone.")
            return
        }

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                speak("Sorry, I couldn't hear that.")
            }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                if (text.isNotBlank()) onText(text)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        speechRecognizer?.startListening(intent)
    }

    private fun sendCommand(command: String) {
        if (command.isBlank()) return
        val base = prefs.getString("backend_url", "http://127.0.0.1:8787")
            ?: "http://127.0.0.1:8787"

        executor.execute {
            try {
                val result = BackendClient.ask(base, command)
                runOnUiThread {
                    if (result.reply.isNotBlank()) speak(result.reply)
                    if (result.action != "none") {
                        val actionResult = CommandRouter.execute(this, result.action, result.value)
                        if (actionResult.isNotBlank()) speak(actionResult)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    speak("I could not reach my AI server. Please check the backend URL and server.")
                }
            }
        }
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        if (::tts.isInitialized) tts.shutdown()
        executor.shutdownNow()
        super.onDestroy()
    }
}

@Composable
fun KanhaApp(
    initialUrl: String,
    savedVoice: String,
    availableVoices: List<Voice>,
    onSaveUrl: (String) -> Unit,
    onSaveVoice: (String) -> Unit,
    onOpenAccessibility: () -> Unit,
    onSpeak: (String) -> Unit,
    onVoice: (String) -> Unit,
    onSend: (String) -> Unit
) {
    var input by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    var messages by remember {
        mutableStateOf(
            listOf(
                ChatMessage("Radhe Radhe 🙏 Main Kanha AI hoon. Aap mujhe bolkar ya type karke command de sakte ho.", false)
            )
        )
    }

    if (showSettings) {
        SettingsScreen(
            initialUrl = initialUrl,
            savedVoice = savedVoice,
            availableVoices = availableVoices,
            onBack = { showSettings = false },
            onSaveUrl = onSaveUrl,
            onSaveVoice = onSaveVoice,
            onOpenAccessibility = onOpenAccessibility,
            onSpeak = onSpeak
        )
        return
    }

    Scaffold(
        containerColor = Black,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.horizontalGradient(listOf(Color(0xFF100B05), Color(0xFF241706), Color(0xFF100B05)))
                    )
                    .padding(horizontal = 18.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier.size(48.dp).clip(CircleShape).background(Gold),
                    contentAlignment = Alignment.Center
                ) {
                    Text("🦚", fontSize = 26.sp)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Kanha AI", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Your Voice • Your Phone • Your AI", color = Muted, fontSize = 11.sp)
                }
                IconButton(onClick = { showSettings = true }) {
                    Icon(Icons.Default.Settings, "Settings", tint = Gold)
                }
            }
        },
        bottomBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Card)
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { onVoice { text -> messages = messages + ChatMessage(text, true); onSend(text) } },
                    modifier = Modifier.background(Gold, CircleShape)
                ) {
                    Icon(Icons.Default.Mic, "Voice", tint = Black)
                }
                Spacer(Modifier.width(8.dp))
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Type a command…", color = Muted) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = White,
                        unfocusedTextColor = White,
                        focusedBorderColor = Gold,
                        unfocusedBorderColor = GoldDark
                    ),
                    shape = RoundedCornerShape(18.dp)
                )
                Spacer(Modifier.width(8.dp))
                IconButton(
                    onClick = {
                        val text = input.trim()
                        if (text.isNotBlank()) {
                            messages = messages + ChatMessage(text, true)
                            input = ""
                            onSend(text)
                        }
                    }
                ) {
                    Icon(Icons.Default.Send, "Send", tint = Gold)
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).background(Black)) {
            Spacer(Modifier.height(18.dp))
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                PremiumChip("🎙 Voice Control")
                PremiumChip("✨ Smart AI")
                PremiumChip("🔐 Safe Actions")
            }

            LazyColumn(
                modifier = Modifier.weight(1f).padding(horizontal = 14.dp),
                contentPadding = PaddingValues(vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages) { message ->
                    MessageBubble(message)
                }
            }
        }
    }
}

@Composable
private fun PremiumChip(text: String) {
    Surface(
        color = Card,
        shape = RoundedCornerShape(50),
        border = androidx.compose.foundation.BorderStroke(1.dp, GoldDark)
    ) {
        Text(text, color = Gold, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp))
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            color = if (message.fromUser) Color(0xFF3A280C) else Card,
            shape = RoundedCornerShape(18.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, if (message.fromUser) GoldDark else Color(0xFF352A17)),
            modifier = Modifier.widthIn(max = 330.dp)
        ) {
            Text(
                message.text,
                color = if (message.fromUser) Gold else White,
                fontSize = 15.sp,
                modifier = Modifier.padding(14.dp)
            )
        }
    }
}

@Composable
fun SettingsScreen(
    initialUrl: String,
    savedVoice: String,
    availableVoices: List<Voice>,
    onBack: () -> Unit,
    onSaveUrl: (String) -> Unit,
    onSaveVoice: (String) -> Unit,
    onOpenAccessibility: () -> Unit,
    onSpeak: (String) -> Unit
) {
    val context = LocalContext.current
    var url by remember { mutableStateOf(initialUrl) }
    var selectedVoice by remember { mutableStateOf(savedVoice) }

    Scaffold(
        containerColor = Black,
        topBar = {
            Row(
                Modifier.fillMaxWidth().padding(18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Settings",
                    color = Gold,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = onBack) { Text("Done", color = Gold) }
            }
        }
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text("AI Backend", color = Gold, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Backend URL") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = White,
                        unfocusedTextColor = White,
                        focusedLabelColor = Gold,
                        unfocusedLabelColor = Muted,
                        focusedBorderColor = Gold,
                        unfocusedBorderColor = GoldDark
                    )
                )
                Spacer(Modifier.height(6.dp))
                Button(
                    onClick = { onSaveUrl(url); onSpeak("Backend URL saved.") },
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Black)
                ) { Text("Save backend") }
            }

            item {
                Text("Indian Voice", color = Gold, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Available en-IN voices installed on your phone are listed below. Voice gender labels depend on the TTS engine.",
                    color = Muted,
                    fontSize = 13.sp
                )
                Spacer(Modifier.height(8.dp))

                if (availableVoices.isEmpty()) {
                    Text(
                        "No en-IN voice was found. Install an Indian-English voice in Android TTS settings.",
                        color = Muted,
                        fontSize = 13.sp
                    )
                } else {
                    availableVoices.forEach { voice ->
                        val label = voice.name.replace('_', ' ')
                        val selected = selectedVoice == voice.name
                        OutlinedButton(
                            onClick = {
                                selectedVoice = voice.name
                                onSaveVoice(voice.name)
                                onSpeak("Indian voice selected.")
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = if (selected) Black else Gold,
                                containerColor = if (selected) Gold else Color.Transparent
                            )
                        ) {
                            Text(label)
                        }
                    }
                }

                Spacer(Modifier.height(4.dp))
                Button(
                    onClick = {
                        context.startActivity(Intent("com.android.settings.TTS_SETTINGS"))
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Card, contentColor = Gold)
                ) {
                    Icon(Icons.Default.VolumeUp, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Open Android TTS settings")
                }
            }

            item {
                Text("Phone Control", color = Gold, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Accessibility Service is optional. Enable it only if you want Kanha AI to click visible controls in another app at your request.",
                    color = Muted,
                    fontSize = 13.sp
                )
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = onOpenAccessibility,
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Black)
                ) { Text("Enable accessibility") }
            }

            item {
                Text("Security", color = Gold, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Kanha AI does not automate OTPs, passwords, payments or hidden surveillance. WhatsApp messages open the compose screen so you can press Send yourself.",
                    color = Muted,
                    fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
fun KanhaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Gold,
            onPrimary = Black,
            background = Black,
            surface = Card,
            onSurface = White
        ),
        content = content
    )
}
