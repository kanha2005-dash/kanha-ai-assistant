Open this folder in Android Studio. If Android Studio asks to upgrade Gradle/AGP, use its Upgrade Assistant rather than manually guessing versions.

A Gradle wrapper is not bundled in this starter ZIP; Android Studio can generate/sync it automatically for the selected compatible Gradle version.
