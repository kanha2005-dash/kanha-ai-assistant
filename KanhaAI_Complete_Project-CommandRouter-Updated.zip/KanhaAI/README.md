# Kanha AI Assistant — Premium Android Starter

Kanha AI is a black + gold Android AI assistant with:
- premium Krishna/Kanha-inspired avatar branding
- text chat
- Android voice input
- Android Text-to-Speech output
- Indian-English voice selection when an `en-IN` voice is installed
- AI backend using the OpenAI Responses API
- local chat history
- safe Android actions
- optional AccessibilityService for user-requested UI assistance

## Important limitations

Android does not give a normal app unrestricted control over another app. The project therefore uses Android intents and, when the user explicitly enables it, AccessibilityService for permitted UI assistance.

Payment, OTP, passwords, account changes and other sensitive actions are intentionally not automated.

The AI API key MUST stay on the backend. Never put it in the Android APK.

## Project

KanhaAI/
  android/
  backend/
  docs/
  branding/

## Build

Open the `android` folder in Android Studio, sync Gradle and Run.

## Backend

Requires Node.js 20+.

    cd backend
    npm install
    cp .env.example .env
    # add OPENAI_API_KEY
    npm start

Then set the backend URL in Kanha AI Settings.

For backend on the same PC and phone on the same Wi-Fi:
    http://YOUR_PC_LAN_IP:8787

For backend on the same Android phone through Termux:
    http://127.0.0.1:8787

## Voice

The Android app uses the phone's installed TTS engine. It searches for `en-IN` voices and exposes them as Indian-English options when available. Voice names and gender metadata vary by device/TTS engine, so the app cannot truthfully guarantee that every phone will contain a male and female Indian voice.

For a guaranteed cloud Indian male/female voice, connect a dedicated Indian-English TTS provider later; the backend boundary is already separated for that extension.

## Example commands

YouTube kholo
Chrome kholo
WhatsApp kholo
Camera kholo
Settings kholo
Google Maps kholo
Open website example.com
WhatsApp message "Hello" to 9876543210
Visible screen par Settings click karo

The last action requires the user to enable Kanha AI Accessibility Service.
