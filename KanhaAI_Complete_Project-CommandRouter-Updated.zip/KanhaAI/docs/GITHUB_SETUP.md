# GitHub setup

Create a repository named `kanha-ai-assistant`.

From the extracted project root:

    git init
    git add .
    git commit -m "Initial Kanha AI Assistant"
    git branch -M main
    git remote add origin https://github.com/YOUR_USERNAME/kanha-ai-assistant.git
    git push -u origin main

Never commit `.env`, API keys, keystores or local secrets.

Recommended production layout:

Android app
    |
   HTTPS
    |
Kanha backend
    |
OpenAI API

Keep OPENAI_API_KEY only on the server.
