# Android setup — step by step

## A. Install Android Studio

Install the current stable Android Studio from the official Android Developers website.

## B. Open Kanha AI

1. Extract the ZIP.
2. Open Android Studio.
3. File -> Open.
4. Select `KanhaAI/android`.
5. Allow Gradle sync.
6. Install any SDK components Android Studio asks for.

The project is configured for Java 17 and compileSdk 35.

## C. Connect your Android phone

On your phone:
1. Settings -> About phone.
2. Tap Build number 7 times.
3. Open Developer options.
4. Turn on USB debugging.
5. Connect the USB cable.
6. Accept the RSA debugging prompt.
7. Press Run in Android Studio.

## D. Backend on a computer

From a terminal:

    cd KanhaAI/backend
    npm install
    cp .env.example .env

Put your API key in `.env`:

    OPENAI_API_KEY=your_key_here
    OPENAI_MODEL=gpt-5.6-luna

Start:

    npm start

Find your computer's LAN IP, e.g. `192.168.1.5`.

In Kanha AI -> Settings -> Backend URL enter:

    http://192.168.1.5:8787

Phone and computer must be on the same Wi-Fi. If Windows Firewall asks, allow Node on the Private network.

## E. Backend directly on Android with Termux

Install Termux from a trusted source, then:

    pkg update
    pkg install nodejs
    cd ~/kanha-ai/backend
    npm install
    export OPENAI_API_KEY="your_key_here"
    export OPENAI_MODEL="gpt-5.6-luna"
    npm start

Use:

    http://127.0.0.1:8787

## F. Enable accessibility only when needed

Android Settings -> Accessibility -> Installed/Downloaded apps -> Kanha AI -> On.

This is required for commands such as clicking visible text in another app.

## G. Voice

Allow microphone permission.

Open Kanha AI -> Settings -> Voice.

Choose an installed Indian-English (`en-IN`) voice. If your phone does not provide both male and female Indian voices, install/configure a TTS engine that does.

## H. Release APK

Android Studio:
Build -> Generate App Bundle / APK -> Generate APK.

For a Play Store release, create a signed release build and keep the signing key secure.
